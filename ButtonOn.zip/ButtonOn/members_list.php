<?php
session_start();
include 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Members | Admin</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: var(--light-gray); }
        .container { max-width: 1000px; margin: 40px auto; background: white; padding: 40px; border: 1px solid var(--border-color); }
        
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 10px; border-bottom: 2px solid black; text-transform: uppercase; font-size: 0.8rem; }
        td { padding: 15px 10px; border-bottom: 1px solid #eee; }
        
        .role-badge { padding: 4px 8px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; background: #eee; }
        .role-admin { background: black; color: white; }
    </style>
</head>
<body>

    <nav style="background: white; border-bottom: 1px solid var(--border-color); padding: 15px 40px;">
        <div class="logo">ButtonOn <span style="font-size: 0.8rem; color: var(--accent-red);">ADMIN</span></div>
        <div class="nav-links">
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </nav>

    <div class="container">
        <h2>Registered Users</h2>
        <br>
        <table>
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Date Joined</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM users ORDER BY created_at DESC";
                $result = mysqli_query($conn, $sql);
                
                while ($row = mysqli_fetch_assoc($result)):
                    $role_style = ($row['role'] == 'admin') ? 'role-admin' : '';
                ?>
                <tr>
                    <td>#<?php echo $row['user_id']; ?></td>
                    <td><b><?php echo $row['full_name']; ?></b></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><span class="role-badge <?php echo $role_style; ?>"><?php echo $row['role']; ?></span></td>
                    <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</body>
</html>