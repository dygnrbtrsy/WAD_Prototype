<?php
include 'db_connect.php';
include 'header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role'] = $user['role'];
        if ($user['role'] === 'admin') {
            header("Location: admin_dashboard.php");
        } else {
            header("Location: dashboard.php");
        }
        exit();

    } else {
        echo "<script>
            if (confirm('Invalid Login. Please Sign Up First.\\n\\nClick OK to register.')) {
                window.location.href = 'register.php';
            }
        </script>";
    }
}
?>

<div class="section-header">
    <h2>Login</h2>
</div>

<div style="padding: 20px; max-width: 400px; margin: 0 auto;">
    <form method="POST" style="display: flex; flex-direction: column; gap: 15px;">
        <input type="email" name="email" placeholder="Email" required style="padding: 12px; border: 1px solid #ddd;">
        <input type="password" name="password" placeholder="Password" required style="padding: 12px; border: 1px solid #ddd;">
        <button type="submit" style="background: black; color: white; padding: 15px; border: none; font-weight: 700; cursor: pointer;">LOG IN</button>
    </form>
</div>

</body>
</html>