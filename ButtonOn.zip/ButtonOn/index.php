<?php
include 'db_connect.php';
include 'header.php';
?>

<!-- Mosaic Hero Section -->
<div class="mosaic-hero">

<?php
$sections = [
    'New Arrivals' => 'New Arrivals',
    'Modest Wear'  => 'Modest',
    'Dresses'=> 'Dress'
];

$index = 0;

foreach ($sections as $title => $category):

    $sql = "SELECT image_url FROM products WHERE category='$category' LIMIT 1";
    $result = mysqli_query($conn, $sql);
    $product = mysqli_fetch_assoc($result);

    if (!$product) continue;
?>

    <div class="mosaic-item <?= $index === 0 ? 'large' : '' ?> animate-mosaic"
        style="background-image: url('<?= $product['image_url'] ?>');">

        <div class="mosaic-text">
            <div class="mosaic-title"><?= strtoupper($title) ?></div>
        </div>
    </div>

<?php
$index++;
endforeach;
?>

</div>

<!-- Featured Products Section -->
<div class="section-header">
    <h2 class="section-title">Featured Products</h2>
    <a href="products.php" class="view-all-btn">View All</a>
</div>

<div class="product-grid">
<?php
$sql = "SELECT * FROM products LIMIT 4";
$result = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_assoc($result)):
?>
    <div class="product-card">
        <div class="img-box">
            <img src="<?= $row['image_url'] ?>" alt="<?= $row['name'] ?>" style="width:100%; height:100%; object-fit:cover;">
        </div>
        <div class="p-info">
            <div class="p-title"><?= $row['name'] ?></div>
            <div class="p-price">RM <?= number_format($row['price'], 2) ?></div>
        </div>
    </div>
<?php endwhile; ?>
</div>

<!-- Anime.js CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js"></script>

<!-- Animate Mosaic Items -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    anime({
        targets: '.animate-mosaic',
        translateY: [50, 0],        // slide up
        opacity: [0, 1],            // fade in
        scale: [0.95, 1],           // slight zoom
        easing: 'easeOutExpo',
        duration: 1200,
        delay: anime.stagger(200)   // stagger between items
    });
});
</script>

<?php
// include 'footer.php'; // Uncomment if you have a footer
?>
