<?php
include 'db_connect.php';
include 'header.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$uid = $_SESSION['user_id'];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['full_name']);
    mysqli_query($conn, "UPDATE users SET full_name = '$name' WHERE user_id = '$uid'");
    $_SESSION['full_name'] = $name;
    echo "<script>alert('Updated!');</script>";
}
?>
<div class="section-header"><h2>Edit Details</h2></div>
<div style="padding: 20px;">
    <form method="POST">
        <label>Display Name:</label><br>
        <input type="text" name="full_name" value="<?php echo $_SESSION['full_name']; ?>" style="padding: 10px; margin-top: 10px;">
        <button type="submit" style="background: black; color: white; padding: 10px;">SAVE</button>
    </form>
</div>
</body></html>
