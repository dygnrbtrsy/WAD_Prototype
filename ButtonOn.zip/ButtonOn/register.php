<?php
include 'db_connect.php';
include 'header.php';
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    if (strlen($password) < 6 || strlen($password) > 8) {
        $message = "Password must be 6-8 characters long.";
    } elseif (!preg_match('/[A-Z]/', $password)) {
        $message = "Password must contain at least one Uppercase letter.";
    } elseif (!preg_match('/[0-9]/', $password)) {
        $message = "Password must contain at least one Number.";
    } elseif (!preg_match('/[\W_]/', $password)) {
        $message = "Password must contain at least one Special Character (!@#$).";
    } elseif (preg_match('/\s/', $password)) {
        $message = "Password must not contain spaces.";
    } else {

        $pass = password_hash($password, PASSWORD_DEFAULT);
        
        $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
        if (mysqli_num_rows($check) > 0) {
            $message = "Email already registered.";
        } else {
            $sql = "INSERT INTO users (full_name, email, password, role) VALUES ('$name', '$email', '$pass', 'member')";
            if (mysqli_query($conn, $sql)) {
                echo "<script>alert('Account Created! Please Login.'); window.location='login.php';</script>";
            } else {
                $message = "Error: " . mysqli_error($conn);
            }
        }
    }
}
?>
<div class="section-header"><h2>Join ButtonOn</h2></div>
<div style="padding: 20px; max-width: 400px; margin: 0 auto;">
    
    <?php if($message): ?>
        <div style="background: #ffe6e6; color: red; padding: 10px; margin-bottom: 15px; border: 1px solid red; font-size: 0.9rem;">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <form method="POST" style="display: flex; flex-direction: column; gap: 15px;">
        <input type="text" name="full_name" placeholder="Full Name" required style="padding: 12px; border: 1px solid #ddd;">
        <input type="email" name="email" placeholder="Email" required style="padding: 12px; border: 1px solid #ddd;">
        
        <div>
            <input type="password" name="password" placeholder="Password" required style="padding: 12px; border: 1px solid #ddd; width: 100%;">
            <small style="color: #666; font-size: 0.75rem;">(6-8 chars, 1 Upper, 1 Number, 1 Special Symbol)</small>
        </div>
        
        <button type="submit" style="background: black; color: white; padding: 15px; border: none; font-weight: 700; cursor: pointer;">CREATE ACCOUNT</button>
    </form>
</div>
</body></html>