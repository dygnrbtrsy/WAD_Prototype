<?php
session_start();
include 'db_connect.php';

if (isset($_GET['del'])) {
    $id = intval($_GET['del']);
    mysqli_query($conn, "DELETE FROM products WHERE product_id=$id");
    header("Location: inventory.php");
    exit();
}

if (isset($_POST['update_btn'])) {
    $id = intval($_POST['product_id']);
    $name = $_POST['name'];
    $cat = $_POST['category'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $desc = $_POST['desc'];

    if (isset($_FILES['img']['name']) && $_FILES['img']['name'] != "") {
        $target = "images/" . basename($_FILES['img']['name']);
        move_uploaded_file($_FILES['img']['tmp_name'], $target);
        $sql = "UPDATE products SET name='$name', category='$cat', price='$price',
                stock_quantity='$stock', description='$desc', image_url='$target'
                WHERE product_id=$id";
    } else {
        $sql = "UPDATE products SET name='$name', category='$cat', price='$price',
                stock_quantity='$stock', description='$desc'
                WHERE product_id=$id";
    }

    mysqli_query($conn, $sql);
    header("Location: inventory.php");
    exit();
}

if (isset($_POST['add_btn'])) {
    $name = $_POST['name'];
    $cat = $_POST['category'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $desc = $_POST['desc'];

    $image_url = "images/default.png";
    if (isset($_FILES['img']['name']) && $_FILES['img']['name'] != "") {
        $target = "images/" . basename($_FILES['img']['name']);
        move_uploaded_file($_FILES['img']['tmp_name'], $target);
        $image_url = $target;
    }

    $sql = "INSERT INTO products (name, category, price, stock_quantity, description, image_url)
            VALUES ('$name', '$cat', '$price', '$stock', '$desc', '$image_url')";
    
    mysqli_query($conn, $sql);
    header("Location: inventory.php");
    exit();
}

$edit_mode = false;
$edit_data = [
    'name' => '', 'category' => '', 'price' => '',
    'stock_quantity' => '100', 'description' => '', 'product_id' => ''
];

if (isset($_GET['edit'])) {
    $edit_mode = true;
    $id = intval($_GET['edit']);
    $res = mysqli_query($conn, "SELECT * FROM products WHERE product_id=$id");
    $edit_data = mysqli_fetch_assoc($res);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory | Admin</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: var(--light-gray); }
        .container { max-width: 1000px; margin: 40px auto; background: white; padding: 40px; border: 1px solid var(--border-color); }
        
        /* Table Styling */
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { text-align: left; padding: 10px; background: #f9f9f9; text-transform: uppercase; font-size: 0.8rem; border-bottom: 2px solid black; }
        td { padding: 15px 10px; border-bottom: 1px solid var(--border-color); vertical-align: middle; }
        
        /* Form Styling */
        input, select, textarea { width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; font-family: inherit; }
        label { font-weight: 600; font-size: 0.9rem; display: block; margin-bottom: 5px; }
        
        /* Button Styles */
        .btn-black { background: black; color: white; border: none; padding: 12px 20px; font-weight: 700; cursor: pointer; text-transform: uppercase; }
        .btn-black:hover { opacity: 0.8; }
        
        .btn-edit { color: blue; font-weight: 600; font-size: 0.8rem; margin-right: 10px; }
        .btn-delete { color: var(--accent-red); font-weight: 600; font-size: 0.8rem; }
        .btn-cancel { background: #ccc; color: black; padding: 12px 20px; text-decoration: none; font-weight: 700; font-size: 0.9rem; text-transform: uppercase; margin-left: 10px; }
        
        .edit-header { color: var(--accent-red); }
    </style>
</head>
<body>

    <nav style="background: white; border-bottom: 1px solid var(--border-color); padding: 15px 40px;">
        <div class="logo">BUTTONON <span style="font-size: 0.8rem; color: var(--accent-red);">ADMIN</span></div>
        <div class="nav-links">
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </nav>

    <div class="container">
        <?php if ($edit_mode): ?>
            <h2 class="edit-header">Edit Product: <?php echo $edit_data['name']; ?></h2>
        <?php else: ?>
            <h2>Add New Product</h2>
        <?php endif; ?>
        
        <br>
        
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="product_id" value="<?php echo $edit_data['product_id']; ?>">

            <label>Product Name</label>
            <input type="text" name="name" value="<?php echo $edit_data['name']; ?>" required>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div>
                    <label>Category</label>
                    <select name="category">
                        <?php 
                        $cats = ["New Arrivals", "Modest", "Bottoms", "Tops", "Skirt", "Dress"];
                        foreach ($cats as $c) {
                            $selected = ($edit_data['category'] == $c) ? 'selected' : '';
                            echo "<option value='$c' $selected>$c</option>";
                        }
                        ?>
                    </select>
                </div>
                <div>
                    <label>Price (RM)</label>
                    <input type="number" step="0.01" name="price" value="<?php echo $edit_data['price']; ?>" required>
                </div>
            </div>

            <label>Stock Quantity</label>
            <input type="number" name="stock" value="<?php echo $edit_data['stock_quantity']; ?>">

            <label>Description</label>
            <textarea name="desc" rows="3"><?php echo $edit_data['description']; ?></textarea>

            <label>
                Product Image
                <?php if ($edit_mode): ?>
                    <span style="font-weight:normal; font-size:0.8rem; color:#666;">(Leave empty to keep current image)</span>
                <?php endif; ?>
            </label>
            <input type="file" name="img" <?php echo $edit_mode ? '' : 'required'; ?>>
            
            <?php if ($edit_mode): ?>
                <button type="submit" name="update_btn" class="btn-black">Update Product</button>
                <a href="inventory.php" class="btn-cancel">Cancel</a>
            <?php else: ?>
                <button type="submit" name="add_btn" class="btn-black">Add Product</button>
            <?php endif; ?>
        </form>

        <br><hr><br>

        <h2>Current Catalog</h2>
        <table>
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Name / Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $res = mysqli_query($conn, "SELECT * FROM products ORDER BY product_id DESC");
                while ($row = mysqli_fetch_assoc($res)): ?>
                <tr>
                    <td>
                        <?php if($row['image_url']): ?>
                            <img src="<?php echo $row['image_url']; ?>" style="width: 50px; height: 60px; object-fit: cover; background: #eee;">
                        <?php endif; ?>
                    </td>
                    <td>
                        <b><?php echo $row['name']; ?></b><br>
                        <span style="font-size: 0.8rem; color: #777;"><?php echo $row['category']; ?></span>
                    </td>
                    <td>RM <?php echo number_format($row['price'], 2); ?></td>
                    <td><?php echo $row['stock_quantity']; ?></td>
                    <td>
                        <a href="inventory.php?edit=<?php echo $row['product_id']; ?>" class="btn-edit">EDIT</a>
                        
                        <a href="inventory.php?del=<?php echo $row['product_id']; ?>" 
                            class="btn-delete"
                            onclick="return confirm('Delete this item?');">REMOVE</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</body>
</html>