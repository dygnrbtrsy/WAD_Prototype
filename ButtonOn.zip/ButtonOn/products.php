<?php
include 'db_connect.php';
include 'header.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}
?>

<link rel="stylesheet" href="products.css">

<div class="section-header">
    <h2 class="section-title">Shop All</h2>
</div>

<!-- Optional: Category links -->
<div class="category-filter" style="padding: 0 40px 20px;">
    <a href="products.php?search=New Arrivals">New Arrivals</a> |
    <a href="products.php?search=Modest">Modest</a> |
    <a href="products.php?search=Bottoms">Bottoms</a> |
    <a href="products.php?search=Tops">Tops</a> |
    <a href="products.php?search=Skirt">Skirts</a> |
    <a href="products.php?search=Dress">Dresses</a> |
    <a href="products.php">All</a>
</div>

<form method="GET" style="padding: 0 40px 20px;">
    <input type="text" name="search" placeholder="Search products..."
            value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
    <button type="submit">Search</button>
</form>

<div class="product-grid">
<?php
$search = $_GET['search'] ?? '';

if ($search) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE name LIKE ? OR category LIKE ?");
    $likeSearch = "%$search%";
    $stmt->bind_param("ss", $likeSearch, $likeSearch);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = mysqli_query($conn, "SELECT * FROM products");
}

while ($row = mysqli_fetch_assoc($result)):
?>
    <div class="product-card">
        <div class="img-box">
            <img src="<?= $row['image_url'] ?>" alt="<?= $row['name'] ?>" style="width:100%; height:100%; object-fit:cover;">
        </div>

        <div class="p-info">
            <div class="p-title"><?= $row['name'] ?></div>
            <div class="p-price">RM <?= number_format($row['price'], 2) ?></div>

            <form method="POST" action="cart.php">
                <input type="hidden" name="product_id" value="<?= $row['product_id'] ?>">
                <button type="submit" name="add_to_cart">Add to Cart</button>
            </form>
        </div>
    </div>
<?php endwhile; ?>
</div>

</body>
</html>
